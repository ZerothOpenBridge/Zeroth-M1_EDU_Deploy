Sunrise5 usb驱动安装 (bl1/bl2/bl33 dfu, fastboot, adb)

- 下载并解压 sunrise5_winusb.zip
- 右键点击"uninstall_driver.bat", 以管理员身份运行, 卸载之前安装的老旧驱动
- 右键点击"install_driver.bat", 以管理员身份运行, 安装本驱动
