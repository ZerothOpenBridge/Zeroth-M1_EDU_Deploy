@echo off

:: 代码页更改为Unicode (UTF-8)
chcp 65001

:: 判断admin权限
REM  --> Check for permissions
    IF "%PROCESSOR_ARCHITECTURE%" EQU "amd64" (
>nul 2>&1 "%SYSTEMROOT%\SysWOW64\cacls.exe" "%SYSTEMROOT%\SysWOW64\config\system"
) ELSE (
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
)

REM --> If error flag set, we do not have admin.
if '%errorlevel%' NEQ '0' (
    echo 请使用管理员权限执行该脚本...
    goto noAdmin
) else ( goto gotAdmin )

:gotAdmin
echo 当前为管理员权限...

:: 切换当前目录为批处理命令路径本身
cd /d %~dp0

echo "卸载Sunrise5 winusb设备驱动程序..."

echo REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36520510
REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36520510 /f

echo REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36521510
REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36521510 /f

echo REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36520520
REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36520520 /f

echo REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36521520
REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36521520 /f

echo REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v 365205102900
REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v 365205102900

echo REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v 365215102900
REG DELETE "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v 365215102900

echo 卸载"Sunrise5 bl1/bl2/bl33 dfu winusb"驱动...
cd ./dfu_winusb
pnputil.exe /delete-driver dfu_winusb.inf /uninstall /force

cd /d %~dp0
echo "当前路径: " %cd%

echo 卸载"Sunrise5 Android fastboot & adb"驱动...
cd ./android_winusb
pnputil.exe /delete-driver android_winusb.inf /uninstall /force

echo "驱动卸载完毕"

cd /d %~dp0
echo "当前路径: " %cd%

:noAdmin

pause
@echo on
