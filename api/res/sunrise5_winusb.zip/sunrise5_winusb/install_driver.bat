@echo off

:: 代码页更改为Unicode (UTF-8)
chcp 65001

:: 判断admin权限
REM  --> Check for permissions
    IF "%PROCESSOR_ARCHITECTURE%" EQU "amd64" (
>nul 2>&1 "%SYSTEMROOT%\SysWOW64\cacls.exe" "%SYSTEMROOT%\SysWOW64\config\system"
) ELSE (
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
)

REM --> If error flag set, we do not have admin.
if '%errorlevel%' NEQ '0' (
    echo 请使用管理员权限执行该脚本...
    goto noAdmin
) else ( goto gotAdmin )

:gotAdmin
echo 当前为管理员权限...

:: 切换当前目录为批处理命令路径本身
cd /d %~dp0

echo "Sunrise5 winusb设备驱动程序..."

echo 忽略"Sunrise5 bootrom dfu"序列号校验
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36520510 /t REG_BINARY /d 01 /f
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36521510 /t REG_BINARY /d 01 /f

echo 忽略"Sunrise5 bl2 dfu"序列号校验
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36520520 /t REG_BINARY /d 01 /f
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags" /v IgnoreHWSerNum36521520 /t REG_BINARY /d 01 /f

echo 忽略"Sunrise5 bootrom dfu"免驱检查
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags\365205102900" /v osvc /t REG_BINARY /d 00 /f
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\usbflags\365215102900" /v osvc /t REG_BINARY /d 00 /f

:: 签名认证
echo 注册签名认证文件Drobotics-Sunrise5-CA.cer
call %SYSTEMROOT%\System32\certutil.exe -f -addstore "Root" build/Drobotics-Sunrise5-CA.cer
call %SYSTEMROOT%\System32\certutil.exe -f -addstore "TrustedPublisher" build/Drobotics-Sunrise5-CA.cer

echo 安装"Sunrise5 bl1/bl2/bl33 dfu winusb"驱动...
cd ./dfu_winusb
pnputil.exe /add-driver dfu_winusb.inf /install

cd /d %~dp0
echo "当前路径: " %cd%

echo 安装"Sunrise5 Android fastboot & adb"驱动...
cd ./android_winusb
pnputil.exe /add-driver android_winusb.inf /install

echo "驱动安装完毕"

cd /d %~dp0
echo "当前路径: " %cd%

:noAdmin

pause
@echo on
